var express = require("express");
var router = express.Router();
var utils = require("../utils/utils.js");
var fs = require("fs");
var path = require("path");
var CONFIG = require("../../config.json");
module.exports = router;

router.route('/loadPres')
    .get(function(request, response){
        fs.readdir(CONFIG.presentationDirectory, function(err, data) {
            if(err)
            {
                callback(err);
            }
            let res={};
            data.forEach(function (fileName) {
                if (path.extname(fileName) === ".json") {
                    var url=CONFIG.presentationDirectory+'/'+fileName;
                    fs.readFile(url,'utf8',function(err,data){
                        if (err) {
                            return console.log(err);
                          }
                        var myJson=JSON.parse(data);
                        console.log(myJson.id);
                        res[myJson.id]=myJson;
                        response.send(res);
                    });
                    
                }
            });
        });
    })